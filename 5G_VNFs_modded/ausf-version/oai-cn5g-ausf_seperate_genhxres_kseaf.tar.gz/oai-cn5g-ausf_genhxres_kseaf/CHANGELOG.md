# RELEASE NOTES : #

## v1.2.0 -- September 2021 ##

* Initial public release
* NRF registration
  - with FQDN DNS resolution
* Full support for Ubuntu18 and RHEL8

## v1.0.0 -- June 2021 ##

* Initial private release
